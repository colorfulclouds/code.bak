/*************************************************************************
	> File Name: close0.c
	> Author: 
	> Mail: 
	> Created Time: 2017年06月05日 星期一 22时23分35秒
 ************************************************************************/

#include<stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>

int main()
{
    close(0);

    int fd = open("1.txt",O_RDONLY);

    char buf[20];
    bzero(buf , sizeof(buf));
    read(fd , buf , sizeof(buf));
puts(buf);
    close(0);

    return 0;
}
