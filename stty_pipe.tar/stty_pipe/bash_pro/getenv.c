/*************************************************************************
	> File Name: getenv.c
	> Author: 
	> Mail: 
	> Created Time: 2017年06月04日 星期日 15时54分06秒
 ************************************************************************/

#include<stdio.h>

extern char **environ;

int main()
{
    int i=0;
    
    char *table[3];
    table[0]="TERM=vt100";
    table[1]="TZ=PST8PDT";
    table[2]=0;

    environ = table;

    execlp("export", "export","TZ",NULL);
  
 //   execlp("env", "env", NULL);

    execlp("date","date",NULL);
    //for(;environ[i];i++)
    //puts(environ[i]);

    return 0;
}
