/*************************************************************************
	> File Name: fork.c
	> Author: 
	> Mail: 
	> Created Time: 2017年05月30日 星期二 22时25分20秒
 ************************************************************************/

#include<stdio.h>
#include <stdlib.h>

int main()
{
    int i =9;
    int pid;

    if( (pid = vfork()) == 0)
    {
        printf("before %d\n", i);
        sleep(2);
        printf("after %d\n", i);
        exit(5);
    }
    else
    {
        int status;

        sleep(1);
        i=10;
        puts("waiting");
        //waitpid(pid , NULL ,0);
     wait(&status);
        printf("status %d\n", status);
    }
    return 0;
}
