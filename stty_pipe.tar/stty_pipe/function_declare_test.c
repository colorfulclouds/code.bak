/*************************************************************************
	> File Name: function_declare_test.c
	> Author: 
	> Mail: 
	> Created Time: 2017年05月30日 星期二 22时09分27秒
 ************************************************************************/

#include<stdio.h>

int main()
{
    int test();
    return 0;
}

int test()
{
    ;
    return 1;
}
